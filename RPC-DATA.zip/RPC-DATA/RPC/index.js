var rpc = require("discord-rpc")
const client = new rpc.Client({ transport: 'ipc' })
client.on('ready', () => {
	client.request('SET_ACTIVITY', {
		pid: process.pid,
		activity : {
			details : "modded by Wackelpudding",
			assets : {
				large_image : "icon",
				large_text : "PuddingHack - 1.18.2"
				
			},
			buttons : [{label : "Download" , url : "https://www.youtube.com/watch?v=gk5UJ5PpTe0"}]
		}
	})
})
client.login({ clientId : "974795147080507443" }).catch(console.error);
