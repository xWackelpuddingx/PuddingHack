package org.bleachhack.gui;

import java.net.http.HttpResponse.BodyHandlers;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.bleachhack.BleachHack;
import org.bleachhack.util.io.BleachFileMang;
import org.bleachhack.gui.window.Window;
import org.bleachhack.gui.window.WindowScreen;
import org.bleachhack.gui.window.widget.WindowScrollbarWidget;
import org.bleachhack.gui.window.widget.WindowTextWidget;
import org.bleachhack.gui.window.widget.WindowWidget;
import org.bleachhack.util.collections.ImmutablePairList;
import org.bleachhack.util.io.BleachJsonHelper;
import org.bleachhack.util.io.BleachOnlineMang;

import com.google.gson.JsonObject;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.LiteralText;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.bleachhack.event.events.EventPacket;
import org.bleachhack.event.events.EventTick;
import org.bleachhack.eventbus.BleachSubscribe;
import org.bleachhack.module.Module;
import org.bleachhack.module.ModuleCategory;
import org.bleachhack.setting.module.SettingMode;
import org.bleachhack.setting.module.SettingSlider;
import org.bleachhack.setting.module.SettingToggle;
import org.bleachhack.util.BleachLogger;
import org.bleachhack.util.world.EntityUtils;
import org.bleachhack.util.world.WorldUtils;

import com.google.gson.JsonPrimitive;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.SharedConstants;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.realms.gui.screen.RealmsMainScreen;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import org.bleachhack.gui.effect.ParticleManager;
import org.bleachhack.gui.window.widget.WindowButtonWidget;
import org.bleachhack.module.mods.UI;
import org.bleachhack.util.io.BleachFileHelper;

import net.minecraft.client.MinecraftClient;

import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.awt.Desktop;
import java.io.*;

import java.net.http.HttpResponse.BodyHandlers;
import java.util.List;
import java.util.Random;
import java.util.*;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;

public class WaypointScreen extends WindowScreen {
	private static Path dir;
	public static WaypointScreen INSTANCE = new WaypointScreen();
	public boolean loaded = false;
	List <String> wayp = org.bleachhack.util.io.BleachFileMang.readFileLines("WaypointNamelist.txt");
	List <String> waypcoords= org.bleachhack.util.io.BleachFileMang.readFileLines("Waypointlist.txt");
	private WindowScrollbarWidget scrollbar;
	int add = 0;
	int rep = 0;
	int actualrep = 0;
	String coords = "x " + waypcoords.get(0) + "y " + waypcoords.get(1) + "z " + waypcoords.get(2);
public WaypointScreen() {
		super(new LiteralText("Waypoints"));
	}
public void openfile(String ask) {
		if(ask =="Name")
		{
        try
        { 
         Runtime.getRuntime().exec("cmd /c start cmd.exe /K \"start %appdata%/.minecraft/bleach/WaypointNamelist.txt\"");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
	else
	{
		{
	        try
	        { 
	         Runtime.getRuntime().exec("cmd /c start cmd.exe /K \"start %appdata%/.minecraft/bleach/Waypointlist.txt\"");
	        }
	        catch (Exception e)
	        {
	            e.printStackTrace();
	        }
	}
	}
}
public void external()
{
	init();
}
    
	public void init() {
		actualrep = 0;
		wayp = org.bleachhack.util.io.BleachFileMang.readFileLines("WaypointNamelist.txt");
		waypcoords= org.bleachhack.util.io.BleachFileMang.readFileLines("Waypointlist.txt");
		dir = Paths.get(MinecraftClient.getInstance().runDirectory.getPath(), "bleach/");
		if (!dir.toFile().exists()) {
			dir.toFile().mkdirs();
		}
		add = 0;
		rep = 0;
		String path = "WaypointNamelist.txt";
		String direct = ""+dir;
		loaded = true;
		super.init();
		int y = 210;
		clearWindows();
		addWindow(new Window(width / 8,
				height / 8,
				width - width / 8,
				height - height / 8, "Waypoints", new ItemStack(Items.WOODEN_HOE)));

		int w = getWindow(0).x2 - getWindow(0).x1;
		int h = getWindow(0).y2 - getWindow(0).y1;
		
		
		getWindow(0).addWidget(new WindowTextWidget(LiteralText.EMPTY, true, WindowTextWidget.TextAlign.MIDDLE, 3f, w / 2, h / 4 - 25, 0)
				.withRenderEvent((widget, ms, wx, wy) -> {
					MutableText bhText = new LiteralText("");

					int i = 0;
					for (char c: "Waypoints".toCharArray()) {
						int fi = i++;
						bhText.append(
								new LiteralText(String.valueOf(c)).styled(s -> s.withColor(TextColor.fromRgb(UI.getRainbowFromSettings(fi)))));
					}

					((WindowTextWidget) widget).setText(bhText);
				}));
				if(waypcoords.size()>0)
				{
					for(int i = 0;i<waypcoords.size()/3;i++)
					{
						if(i!=0)
						{
						add =add+20;
						}
						double x = Math.round(Double.parseDouble(waypcoords.get(rep)));
						double y2 = Math.round(Double.parseDouble(waypcoords.get(rep+1)));
						double z = Math.round(Double.parseDouble(waypcoords.get(rep+2)));
						actualrep++;
						rep = rep +3;
					String coords = "x: " + x + " y: " + y2 + " z: " + z;
					String nethercoords = "x: " + x/8+ " y: " + y2/8 + " z: " + z/8;
					if(wayp.size()>=actualrep)
					{
					getWindow(0).addWidget(new WindowTextWidget(
							new LiteralText(wayp.get(i)).styled(s -> s.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new LiteralText("\u00A7a"+coords+"\n\n\u00a7f"+"\u00A74"+nethercoords)))),
							true, WindowTextWidget.TextAlign.MIDDLE, w / 2, 120+add, 0x51eff5));
					}
					else
					{
						getWindow(0).addWidget(new WindowTextWidget(
								new LiteralText("Unnamed "+i).styled(s -> s.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new LiteralText("\u00A7a"+coords+"\n\n\u00a7f"+nethercoords)))),
								true, WindowTextWidget.TextAlign.MIDDLE, w / 2, 120+add, 0x51eff5));
					}
				}
			}
				else
				{
					
					getWindow(0).addWidget(new WindowButtonWidget(w / 2 - 100, h / 4 + 38, w / 2 + 100, h / 4 + 58, ("add waypoints"), () -> {  
						openfile("Name");
						openfile("coords");
					}
					
				));
				}
				
				getWindow(0).addWidget(new WindowButtonWidget(w / 2 - 164, h / 4 + 62, w / 2 - 104, h / 4 + 82, ("Change"), () -> {
					openfile("Name");
					openfile("Coords");
				}
			));
				getWindow(0).addWidget(new WindowButtonWidget(w / 2 - 164, h / 4 + 38, w / 2 - 104, h / 4 + 58, ("Reload"), () -> {
					init();
				}
			));
				
				for (WindowWidget widget: getWindow(0).getWidgets()) {
					if (!(widget instanceof WindowScrollbarWidget)) {
						widget.cullY = true;
					}
				}

				scrollbar = getWindow(0).addWidget(new WindowScrollbarWidget(w - 11, 12, y - 10, h - 13, 0));
			}
		
	@Override
	public void render(MatrixStack matrices, int mouseX, int mouseY, float delta)
	{
		this.renderBackground(matrices);
		
		if(!loaded)
		{
			int scroll = scrollbar.getPageOffset();
		init();
		scrollbar.setPageOffset(scroll);
		}
		
		int offset = scrollbar.getOffsetSinceRender();
		for (WindowWidget widget: getWindow(0).getWidgets()) {
			if (!(widget instanceof WindowScrollbarWidget)) {
				widget.y1 -= offset;
				widget.y2 -= offset;
			}
		}

		super.render(matrices, mouseX, mouseY, delta);
	}
	public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
		scrollbar.moveScrollbar((int) -amount * 7);

		return super.mouseScrolled(mouseX, mouseY, amount);
	}
}