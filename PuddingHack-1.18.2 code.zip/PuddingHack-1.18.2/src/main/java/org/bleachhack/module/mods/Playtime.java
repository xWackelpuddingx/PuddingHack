package org.bleachhack.module.mods;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.bleachhack.event.events.EventPacket;
import org.bleachhack.event.events.EventTick;
import org.bleachhack.eventbus.BleachSubscribe;
import org.bleachhack.module.Module;
import org.bleachhack.module.ModuleCategory;
import org.bleachhack.setting.module.SettingMode;
import org.bleachhack.setting.module.SettingSlider;
import org.bleachhack.setting.module.SettingToggle;
import org.bleachhack.util.world.EntityUtils;
import org.bleachhack.util.world.WorldUtils;
import org.bleachhack.util.BleachLogger;

import net.minecraft.text.LiteralText;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;

public class Playtime extends Module{
	private int tickcount;
	private int seconds;
	private int minutes;
	private int hours;
	private boolean counting;
	public Playtime() 
	{
		
	super("Playtime", KEY_UNBOUND, ModuleCategory.RENDER, "tracks the time played and gives updates in Chat");
	
	}
	@Override
	public void onEnable(boolean inWorld) {
		super.onEnable(inWorld);
		tickcount = 0;
		seconds = 0;
		hours = 0;
		counting = true;
	}
	@Override
	public void onDisable(boolean inWorld) {
		super.onDisable(inWorld);
		tickcount = 0;
		counting = false;
	}
	@BleachSubscribe
	public void onTick(EventTick event) {
		if (counting == true)
		{
		tickcount++;
		if (tickcount == 20)
		{
			seconds = seconds+1;
			tickcount = 0;
		}
		if (seconds == 60)
		{
			minutes = minutes+1;
			seconds = 0;
		}
		if ((minutes % 5 == 0)&&(minutes != 0)&&(seconds == 0)&&(tickcount ==0))
		{
			if (hours == 0)
			{
			BleachLogger.info(new LiteralText(
					"you are playing for " + minutes + " minutes and " + seconds + " seconds"));
			}
			if (hours == 1)
			{
			BleachLogger.info(new LiteralText(
					"you are playing for " + hours + "hour " + minutes + "minutes and " + seconds + "seconds"));
			}
			if (hours > 1)
			{
			BleachLogger.info(new LiteralText(
					"you are playing for " + hours + "hours " + minutes + "minutes and " + seconds + "seconds"));
			}
		}
		if (minutes == 60)
		{
			hours++;
			minutes  = 0;
		}
		}
	}
}
