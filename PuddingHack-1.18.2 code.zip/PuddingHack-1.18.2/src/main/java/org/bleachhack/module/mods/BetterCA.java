package org.bleachhack.module.mods;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.bleachhack.event.events.EventTick;
import org.bleachhack.eventbus.BleachSubscribe;
import org.bleachhack.module.Module;
import org.bleachhack.module.ModuleCategory;
import org.bleachhack.module.ModuleManager;
import org.bleachhack.setting.module.SettingToggle;
import org.bleachhack.util.BleachLogger;
import org.bleachhack.event.events.EventPacket;
import org.bleachhack.setting.module.SettingMode;
import org.bleachhack.setting.module.SettingSlider;
import org.bleachhack.util.world.EntityUtils;
import org.bleachhack.util.world.WorldUtils;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.Util;
import net.minecraft.text.LiteralText;
public class BetterCA extends Module {
	public BetterCA() {
		super("BetterCA", KEY_UNBOUND, ModuleCategory.COMBAT, "this may or may not just toggle meteor CA");
	}
	@Override
	public void onDisable(boolean inWorld)
	{
		super.onDisable(inWorld);
		mc.player.sendChatMessage("#toggle Crystal-Aura");
	}
	@Override
	public void onEnable(boolean inWorld)
	{
		super.onEnable(inWorld);
		mc.player.sendChatMessage("#toggle Crystal-Aura");
	}
}