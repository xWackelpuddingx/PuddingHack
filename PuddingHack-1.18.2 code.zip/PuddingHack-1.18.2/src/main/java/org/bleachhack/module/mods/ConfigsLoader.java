//package org.bleachhack.module.mods;

//import java.util.Collections;
//import java.util.Comparator;
//import java.util.List;
//import java.util.Optional;
//import java.util.stream.Collectors;
//import java.util.stream.Stream;

//import org.bleachhack.event.events.EventTick;
//import org.bleachhack.eventbus.BleachSubscribe;
//import org.bleachhack.module.Module;
//import org.bleachhack.module.ModuleCategory;
//import org.bleachhack.module.ModuleManager;
//import org.bleachhack.setting.module.SettingToggle;
//import org.bleachhack.util.BleachLogger;
//import org.bleachhack.event.events.EventPacket;
//import org.bleachhack.setting.module.SettingMode;
//import org.bleachhack.setting.module.SettingSlider;
//import org.bleachhack.util.world.EntityUtils;
//import org.bleachhack.util.world.WorldUtils;
//import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
//import net.minecraft.util.Util;
//import net.minecraft.text.LiteralText;

//public class ConfigsLoader extends Module {
	//public static boolean enabled = false;
	//public ConfigsLoader() {
		//super("ConfigsLoader", KEY_UNBOUND, ModuleCategory.WORLD, "Loads specific configs",
				//new SettingToggle("Combat", false).withDesc("enable typical combat modules"),
				//new SettingToggle("BaseHunt", false).withDesc("enable typical Basehunting modules"),
				//new SettingToggle("chill", false).withDesc("Cause sometimes i feel like not doing anything"));
		
	//}


	//@Override
	//public void onDisable(boolean inWorld)
	//{
		//enabled = false;
		//super.onEnable(inWorld);
		//if (getSetting(0).asToggle().getState() == true)
		//{
		//if (org.bleachhack.module.mods.CrystalAura.enabled = true)
		//{
		//	mc.player.sendChatMessage("$toggle CrystalAura");
		//}
		//if (org.bleachhack.module.mods.HoleESP.enabled = true)
		//{
		//	mc.player.sendChatMessage("$toggle HoleESP");
		//}
		//}
		//if (getSetting(1).asToggle().getState() == true)
		//{
		//if (org.bleachhack.module.mods.Search.enabled = true)
		//{
			//mc.player.sendChatMessage("$toggle Search");
		//}
		//if (org.bleachhack.module.mods.ElytraFly.enabled = true)
		//{
			//mc.player.sendChatMessage("$toggle ElytraFly");
		//}
		//}
		//if (getSetting(2).asToggle().getState() == true)
		//{
			//mc.player.sendChatMessage("$toggle dance");
		//}
	//}
	//@Override
	//public void onEnable(boolean inWorld)
	//{
		//super.onEnable(inWorld);
		
		//if (getSetting(0).asToggle().getState() == true)
		//{
		//if (org.bleachhack.module.mods.CrystalAura.enabled == false)
		//{
			//mc.player.sendChatMessage("$toggle CrystalAura");
		//}
		//if (org.bleachhack.module.mods.HoleESP.enabled == false)
		//{
			//mc.player.sendChatMessage("$toggle HoleESP");
		//}
		//}
		//if (getSetting(1).asToggle().getState() == true)
		//{
		//if (org.bleachhack.module.mods.Search.enabled == false)
		//{
			//mc.player.sendChatMessage("$toggle Search");
		//}
		//if (org.bleachhack.module.mods.ElytraFly.enabled == false)
		//{
		//	mc.player.sendChatMessage("$toggle ElytraFly");
		//}
		//}
		//if (getSetting(2).asToggle().getState()==true)
		//{
			//mc.options.sneakKey.setPressed(true);
			//mc.player.sendChatMessage("$toggle dance");
			//try {
				//Util.getOperatingSystem().open("https://youtu.be/fLexgOxsZu0");
			//} catch (Exception e) {
				//e.printStackTrace();
			//}
		//}
	//}
//} //https://youtu.be/fLexgOxsZu0