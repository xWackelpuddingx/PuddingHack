package org.bleachhack.module.mods;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.bleachhack.event.events.EventPacket;
import org.bleachhack.event.events.EventTick;
import org.bleachhack.eventbus.BleachSubscribe;
import org.bleachhack.module.Module;
import org.bleachhack.module.ModuleCategory;
import org.bleachhack.setting.module.SettingMode;
import org.bleachhack.setting.module.SettingSlider;
import org.bleachhack.setting.module.SettingToggle;
import org.bleachhack.util.world.EntityUtils;
import org.bleachhack.util.world.WorldUtils;

import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;

public class dance extends Module {

	private boolean packetSent;
	private boolean dance;
	private int tickcount;
	private int multiplier;
	
	public dance() {
		super("dance", KEY_UNBOUND, ModuleCategory.MOVEMENT, "Some men can dance and some use this.",
			new SettingSlider("Delay", 1, 10, 1, 0).withDesc("Delay between sneaking and unsneaking."));
	}
	@Override
	public void onDisable(boolean inWorld) {
		mc.options.sneakKey.setPressed(false);
		if (inWorld)
			mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.RELEASE_SHIFT_KEY));
	
		super.onDisable(inWorld);
		dance = false;
	}
	@Override
	public void onEnable(boolean inWorld) {
		super.onEnable(inWorld);
		multiplier = getSetting(0).asSlider().getValueInt();
		dance = true;
	}
	@BleachSubscribe
	public void onTick(EventTick event) {
		if (dance == true) {
			tickcount++;
			if (tickcount==2*multiplier)//*getSetting(1).asSlider().getValueInt()
			{
				mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.PRESS_SHIFT_KEY));
				mc.options.sneakKey.setPressed(true);
			}
			else
			{
				if (tickcount==4*multiplier)
				{
					mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.RELEASE_SHIFT_KEY));
					mc.options.sneakKey.setPressed(false);
					tickcount = 0;
				}
			}
		}
	}
}