//guess whats back,  back again
//spaghetti codes back
//tell a friend
package org.bleachhack.module.mods;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.bleachhack.event.events.EventPacket;
import org.bleachhack.event.events.EventTick;
import org.bleachhack.eventbus.BleachSubscribe;
import org.bleachhack.module.Module;
import org.bleachhack.module.ModuleCategory;
import org.bleachhack.setting.module.SettingMode;
import org.bleachhack.setting.module.SettingSlider;
import org.bleachhack.setting.module.SettingToggle;
import org.bleachhack.util.BleachLogger;
import org.bleachhack.util.world.EntityUtils;
import org.bleachhack.util.world.WorldUtils;
import org.apache.commons.lang3.RandomUtils;
import org.bleachhack.event.events.EventClientMove;

import org.bleachhack.event.events.EventSendMovementPackets;


import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import net.minecraft.text.LiteralText;

public class StraightFly extends Module {
	private int tickcount;
	private boolean on = true;
	private boolean once = true;
	private double enablepos;
	private boolean up;
	private  boolean down;
	private int tracker;
	public StraightFly() {
		super("StraightFly(5.6)", KEY_UNBOUND, ModuleCategory.MOVEMENT, "guess whats back, back again spaghetti codes back  tell a friend",
				new SettingToggle("MathMode", true).withDesc("1+1=cos(360)"),
				new SettingToggle("Normal", true).withDesc("dfvihjosu"));
	}
	@Override
	public void onEnable(boolean inWorld) {
		super.onEnable(inWorld);
		on = true;
		once =true;
		tickcount = 0;
	}
	@Override
	public void onDisable(boolean inWorld) {
		on = false;
		super.onDisable(inWorld);
	}
	
	@BleachSubscribe
	
	public void onTick(EventTick event) {
		if(on !=false)
		{
			
		if(tickcount == 20)
		{
			once = false;
		}
		if(once == true)
		{
			if(tickcount<20)
			{
				if (getSetting(1).asToggle().getState()&&!getSetting(0).asToggle().getState())
				{
				mc.player.setPitch(mc.player.getPitch()-1);
				BleachLogger.info(new LiteralText("Y Position logged in, FlightBot preparing"));
				}
			}
		}
			if (getSetting(0).asToggle().getState())
			{
				if(tickcount==0&&once == true)
				{
				enablepos = mc.player.getY();
				once = false;
				BleachLogger.info(new LiteralText("Y Position logged in, FlightBot preparing"));
				}
				double nowpos = mc.player.getY();
				if(enablepos-0.5>nowpos&&up!=true)
				{
					mc.player.setPitch(mc.player.getPitch()-14);
					up = true;
					down =false;
					tracker = tracker-4;
				}
				else
				{
				if(enablepos+0.5<nowpos&&down!=true)
				{
					mc.player.setPitch(mc.player.getPitch()+14);
					down = true;
					up = false;
					tracker=tracker+4;
				}
				}
			}
				if(getSetting(1).asToggle().getState())
			{
			if(tickcount>20&&tickcount<40)
			{
				mc.player.setPitch(mc.player.getPitch()+2);
			}
		if(tickcount>40)
		{
			mc.player.setPitch(mc.player.getPitch()-2);
		}
		tickcount=tickcount+2;
		if(tickcount==60)
		{
			tickcount=0;
		}
	}
}
	}
}
