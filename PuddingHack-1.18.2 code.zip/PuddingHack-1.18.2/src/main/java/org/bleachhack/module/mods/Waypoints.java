package org.bleachhack.module.mods;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.bleachhack.event.events.EventPacket;
import org.bleachhack.event.events.EventTick;
import org.bleachhack.eventbus.BleachSubscribe;
import org.bleachhack.module.Module;
import org.bleachhack.module.ModuleCategory;
import org.bleachhack.setting.module.SettingMode;
import org.bleachhack.setting.module.SettingSlider;
import org.bleachhack.setting.module.SettingToggle;
import org.bleachhack.util.BleachLogger;
import org.bleachhack.util.world.EntityUtils;
import org.bleachhack.util.world.WorldUtils;
import org.bleachhack.gui.WaypointScreen;

import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.text.LiteralText;

public class Waypoints extends Module {
	public double[] waypointcoordsx = new double[69];
	public double[] waypointcoordsz = new double[69];
	public double[] waypointcoordsy = new double[69];
	public int slot;
	public String[] read = new String[100];
	public Waypoints() {
		super("Waypoints", KEY_UNBOUND, ModuleCategory.RENDER, "save coords because brain returning 404 on getBraincells()",  //add buttons to do
			new SettingToggle("Lock in", false).withDesc("safe current coords(to safe name visit bleach folder)"),
			new SettingToggle("delete", false).withDesc("delete all waypoints(to delete single waypoints visit bleach folder)"),
			new SettingToggle("return", false).withDesc("return coords of slot"),
			new SettingSlider("Slot", 1, 10, 1, 0).withDesc("Array slot to override"),
			new SettingToggle("Window", false).withDesc("open Window"));
	}
	@Override
	public void onEnable(boolean inWorld) {
		super.onEnable(inWorld);
		readandoverwrite();
	}
	public void readandoverwrite()
	{
		List <String> wayp= org.bleachhack.util.io.BleachFileMang.readFileLines("Waypointlist.txt");
		int temp = wayp.size();
		for(int i=0;i<temp;i++)
		{
			if(temp >=3)
			{
		waypointcoordsx[i] = Double.parseDouble(wayp.get(temp-3));   //to double
		waypointcoordsy[i] = Double.parseDouble(wayp.get(temp-2));
		waypointcoordsz[i] = Double.parseDouble(wayp.get(temp-1));
		temp=temp-3;
			}
		}
	}
	public String tostring(double doubl)
	{
		 return "" + doubl;
	}
	public void returnslot(int slot)
	{
		String temp = "x " + waypointcoordsx[slot];
		List <String> wayp= org.bleachhack.util.io.BleachFileMang.readFileLines("WaypointNamelist.txt");
		if(slot+1<=wayp.size())
		{
			BleachLogger.info(new LiteralText(wayp.get(slot)));
		}
		BleachLogger.info(new LiteralText(temp));
		temp = "y" + waypointcoordsy[slot];
		BleachLogger.info(new LiteralText(temp));
		temp = "z" + waypointcoordsz[slot];
		BleachLogger.info(new LiteralText(temp));
		this.setEnabled(false);
	}
	public void deletewaypoints(int slot)
	{
		waypointcoordsx[slot] =0;
		 waypointcoordsy[slot] = 0;
		 waypointcoordsz[slot] = 0;
		 this.setEnabled(false);
		 org.bleachhack.util.io.BleachFileMang.deleteFile("Waypointlist.txt");
	}
	public void makewaypoint()
	{
		 waypointcoordsx[slot] = mc.player.getX();
		 waypointcoordsy[slot] = mc.player.getY();
		 waypointcoordsz[slot] = mc.player.getZ();
		 org.bleachhack.util.io.BleachFileMang.createFile("Waypointlist.txt");
		 org.bleachhack.util.io.BleachFileMang.appendFile("Waypointlist.txt",tostring(waypointcoordsx[slot]));
		 org.bleachhack.util.io.BleachFileMang.appendFile("Waypointlist.txt",tostring(waypointcoordsy[slot]));
		 org.bleachhack.util.io.BleachFileMang.appendFile("Waypointlist.txt",tostring(waypointcoordsz[slot]));
		 org.bleachhack.util.io.BleachFileMang.createFile("WaypointNamelist.txt");
		 this.setEnabled(false);
	}
	@BleachSubscribe
	public void onTick(EventTick event) {
		slot = getSetting(3).asSlider().getValueInt()-1;
		if(getSetting(0).asToggle().getState())
				{
			makewaypoint();
				}
		if(getSetting(1).asToggle().getState())
		{
			deletewaypoints(slot);
		}
		if(getSetting(2).asToggle().getState())
		{
			returnslot(slot);
		}
		if(getSetting(4).asToggle().getState())
		{
			WaypointScreen  ws = new WaypointScreen();
			ws.external();
			mc.setScreen(WaypointScreen.INSTANCE);
			this.setEnabled(false);
		}
	}
}