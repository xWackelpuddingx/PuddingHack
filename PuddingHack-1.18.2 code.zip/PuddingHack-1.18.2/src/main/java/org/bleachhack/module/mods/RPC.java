package org.bleachhack.module.mods;

import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.text.LiteralText;
import net.minecraft.util.math.Vec3d;

import org.apache.commons.lang3.tuple.Pair;
import org.bleachhack.event.events.EventEntityRender;
import org.bleachhack.event.events.EventOpenScreen;
import org.bleachhack.event.events.EventPacket;
import org.bleachhack.event.events.EventTick;
import org.bleachhack.eventbus.BleachSubscribe;
import org.bleachhack.module.Module;
import org.bleachhack.module.ModuleCategory;
import org.bleachhack.setting.module.SettingSlider;
import org.bleachhack.setting.module.SettingToggle;
import org.bleachhack.util.BleachQueue;
import org.bleachhack.util.render.WorldRenderer;
import org.bleachhack.util.world.PlayerCopyEntity;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import java.net.http.HttpResponse.BodyHandlers;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.bleachhack.BleachHack;
import org.bleachhack.util.io.BleachFileMang;
import org.bleachhack.util.collections.ImmutablePairList;
import org.bleachhack.util.io.BleachJsonHelper;
import org.bleachhack.util.io.BleachOnlineMang;

import com.google.gson.JsonObject;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.bleachhack.event.events.EventTick;
import org.bleachhack.eventbus.BleachSubscribe;
import org.bleachhack.module.Module;
import org.bleachhack.module.ModuleCategory;
import org.bleachhack.setting.module.SettingMode;
import org.bleachhack.setting.module.SettingSlider;
import org.bleachhack.setting.module.SettingToggle;
import org.bleachhack.util.BleachLogger;
import org.bleachhack.util.world.EntityUtils;
import org.bleachhack.util.world.WorldUtils;

import com.google.gson.JsonPrimitive;
import net.minecraft.SharedConstants;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.realms.gui.screen.RealmsMainScreen;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableText;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import org.bleachhack.module.mods.UI;
import org.bleachhack.util.io.BleachFileHelper;

import net.minecraft.client.MinecraftClient;

import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.awt.Desktop;
import java.io.*;

import java.net.http.HttpResponse.BodyHandlers;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;

import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;

public class RPC extends Module {
	boolean enabled = false;
	public RPC() {
		super("RPC", KEY_UNBOUND, ModuleCategory.MISC, "flexes your client.");
	}
	@Override
	public void onEnable(boolean inWorld) {
		try
        { 
         Runtime.getRuntime().exec("cmd /c start cmd.exe /K \"start %appdata%/.minecraft/bleach/RPC.bat\"");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
		enabled = true;
	}
	@BleachSubscribe
	public void onTick(EventTick event) {
		if(enabled==false)
		{
			try
	        { 
			Runtime.getRuntime().exec("cmd /c start cmd.exe /K \"start %appdata%/.minecraft/bleach/RPC.bat\"");
	        }
			catch(Exception e)
			{
				e.printStackTrace();
			}
			enabled = true;
		}
	}
}
				
				
				